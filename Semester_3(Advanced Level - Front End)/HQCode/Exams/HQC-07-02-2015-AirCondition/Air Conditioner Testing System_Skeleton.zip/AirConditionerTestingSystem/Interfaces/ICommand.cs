﻿namespace AirConditionerTestingSystem.Interfaces
{
    public interface ICommand
    {
        string Execute();
    }
}