﻿namespace AirConditionerTestingSystem.Interfaces
{
    public interface IUserInterface : IReader, IWriter
    {
    }
}
