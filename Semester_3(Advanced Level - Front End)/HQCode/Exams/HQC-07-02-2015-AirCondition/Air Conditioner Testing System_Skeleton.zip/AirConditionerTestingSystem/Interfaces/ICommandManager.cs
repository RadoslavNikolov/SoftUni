﻿namespace AirConditionerTestingSystem.Interfaces
{
    public interface ICommandManager
    {
        string ExecuteCommand(string commandLine);
    }
}