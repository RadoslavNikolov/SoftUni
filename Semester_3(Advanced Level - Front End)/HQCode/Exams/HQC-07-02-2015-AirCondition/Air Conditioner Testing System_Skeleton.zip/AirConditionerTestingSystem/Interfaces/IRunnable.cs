﻿namespace AirConditionerTestingSystem.Interfaces
{
    public interface IRunnable
    {
        void Run();  
    }
}