﻿namespace AirConditionerTestingSystem.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string message);
    }
}