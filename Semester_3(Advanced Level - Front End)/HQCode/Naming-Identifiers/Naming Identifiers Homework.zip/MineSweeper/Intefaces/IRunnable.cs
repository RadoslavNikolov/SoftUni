﻿namespace Minesweeper.Intefaces
{
    public interface IRunnable
    {
        void Run();
    }
}