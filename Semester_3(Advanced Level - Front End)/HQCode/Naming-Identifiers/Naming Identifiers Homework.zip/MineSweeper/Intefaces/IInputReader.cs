﻿namespace Minesweeper.Intefaces
{
    public interface IInputReader
    {
        string Read();
    }
}