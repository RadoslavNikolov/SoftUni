﻿namespace Minesweeper.Intefaces
{
    public interface IReaderWriter : IInputReader, IOutputWriter
    {        
    }
}