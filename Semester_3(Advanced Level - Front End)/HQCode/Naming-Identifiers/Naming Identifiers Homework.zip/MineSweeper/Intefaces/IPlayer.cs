﻿namespace Minesweeper.Intefaces
{
    public interface IPlayer
    {
        string Name { get;} 

        int Points { get; set; }
    }
}