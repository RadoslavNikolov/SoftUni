﻿using System;

namespace Methods
{
    class Methods
    {
    }
}
