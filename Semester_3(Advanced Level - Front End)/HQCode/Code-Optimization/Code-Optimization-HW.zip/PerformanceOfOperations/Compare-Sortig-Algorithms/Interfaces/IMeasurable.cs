﻿namespace Dompare_Sortig_Algorithms.Interfaces
{
    public interface IMeasurable
    {
        void MeasurePerformance();
    }
}