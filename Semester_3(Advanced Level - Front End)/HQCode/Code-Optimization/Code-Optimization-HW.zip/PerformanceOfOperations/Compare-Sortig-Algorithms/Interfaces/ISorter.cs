﻿namespace Dompare_Sortig_Algorithms.Interfaces
{
    using System.Collections.Generic;

    public interface ISorter
    {
        void Sort(int[] inputArray);
    }
}