﻿namespace Huy_Phuong.Test
{
    using System.Collections.Generic;
    using Infrastructure;

    public class DataBaseProvider
    {
        public IList<ITheatre> GetMockDataBase { get; private set; }
    }
}