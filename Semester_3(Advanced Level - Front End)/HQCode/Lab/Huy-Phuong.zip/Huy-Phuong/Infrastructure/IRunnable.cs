﻿namespace Huy_Phuong.Infrastructure
{
    public interface IRunnable
    {
        void Run();
    }
}