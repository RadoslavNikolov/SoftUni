﻿namespace Huy_Phuong.Infrastructure
{
    public interface IReaderWriter : IInputReader, IOutputWriter
    {
         
    }
}