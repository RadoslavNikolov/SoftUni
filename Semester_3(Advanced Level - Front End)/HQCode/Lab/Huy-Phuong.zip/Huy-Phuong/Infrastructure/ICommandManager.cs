﻿namespace Huy_Phuong.Infrastructure
{
    public interface ICommandManager
    {
        string ExecuteCommand(string commandLine);
    }
}