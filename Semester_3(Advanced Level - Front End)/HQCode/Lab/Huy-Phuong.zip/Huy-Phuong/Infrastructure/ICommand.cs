﻿namespace Huy_Phuong.Infrastructure
{
    using System.Collections.Generic;
    using System.Text;

    public interface ICommand
    {
        string Execute();
    }
}