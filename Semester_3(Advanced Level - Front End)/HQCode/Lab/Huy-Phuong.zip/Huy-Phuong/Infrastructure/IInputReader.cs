﻿namespace Huy_Phuong.Infrastructure
{
    public interface IInputReader
    {
        string Read();
    }
}