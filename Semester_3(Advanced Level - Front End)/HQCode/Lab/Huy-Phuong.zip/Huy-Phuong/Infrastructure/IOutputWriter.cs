﻿namespace Huy_Phuong.Infrastructure
{
    public interface IOutputWriter
    {
        void Print(string message);
    }
}