app.controller('ImageBinding', function($scope){
    var imagesUrls = [
        "http://blog.jimdo.com/wp-content/uploads/2014/01/tree-247122.jpg",
        "http://hdwallpaperd.com/wp-content/uploads/HD-Nature-Wallpaper.jpg",
        "https://newevolutiondesigns.com/images/freebies/nature-hd-background-22.jpg",
        "https://newevolutiondesigns.com/images/freebies/nature-hd-background-10.jpg",
        "http://hdwallpaperd.com/wp-content/uploads/hd-wallpapers-of-nature-134.jpg",
        "http://www.hdwallpapersjpg.com/wp-content/uploads/2015/02/Shady-Clouds-Best-Nature-HD-Wallpaper.jpg"
    ];

    $scope.urls = imagesUrls;
});