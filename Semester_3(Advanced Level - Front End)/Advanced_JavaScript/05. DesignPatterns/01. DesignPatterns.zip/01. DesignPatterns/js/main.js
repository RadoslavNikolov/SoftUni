﻿(function(scope) {
    scope.init();
}(toDo));