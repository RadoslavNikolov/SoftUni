#!/bin/bash
clear
java -jar _10_Print-Deck-Of-Cards.jar