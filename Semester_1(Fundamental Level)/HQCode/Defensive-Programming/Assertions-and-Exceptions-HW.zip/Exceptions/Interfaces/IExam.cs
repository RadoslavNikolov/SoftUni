﻿namespace Exceptions_Homework.Interfaces
{
    using Models;

    public interface IExam
    {
        ExamResult Check(); 
    }
}