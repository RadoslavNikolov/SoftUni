﻿namespace Blobs.Infrastructure
{
    public interface IUpdatable
    {
        void Update();
    }
}