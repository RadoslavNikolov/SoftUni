﻿namespace Blobs.Infrastructure
{
    public interface IReaderWriter : IInputReader, IOutputWriter
    {
        
    }
}