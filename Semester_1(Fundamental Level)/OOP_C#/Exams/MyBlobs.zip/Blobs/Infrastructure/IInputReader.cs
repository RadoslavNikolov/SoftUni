﻿namespace Blobs.Infrastructure
{
    public interface IInputReader
    {
        string Read();
    }
}