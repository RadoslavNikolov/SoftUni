﻿namespace Blobs.Infrastructure
{
    public interface IRunnable
    {
        void Run();
    }
}