﻿namespace Functional_Programming.Models.Enums
{
    public enum Gender
    {
        Female, 
        Male
    }
}