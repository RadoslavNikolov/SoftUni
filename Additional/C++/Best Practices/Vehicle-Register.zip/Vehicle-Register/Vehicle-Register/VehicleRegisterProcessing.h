#pragma once
#include <map>
using namespace std;

struct VehicleRegisterProcessing
{
	void addNewVehicle();
	void searchVehicleByRegNum();	
};

