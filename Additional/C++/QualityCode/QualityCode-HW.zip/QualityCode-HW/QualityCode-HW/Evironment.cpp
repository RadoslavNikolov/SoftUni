#include "Evironment.h"



Evironment::Evironment()
{
}

Evironment::Evironment(unsigned int id, string name, float gravity) : id(id), name(name), gravity(gravity)
{
}


Evironment::~Evironment()
{
}
