// Radoslav Nikolov - rado_niko
#ifndef SpaceXProcessing_hpp
#define SpaceXProcessing_hpp


struct SpaceXProcessing
{
	void addNewFlight();
	void searchForFlightByName();
};

#endif

