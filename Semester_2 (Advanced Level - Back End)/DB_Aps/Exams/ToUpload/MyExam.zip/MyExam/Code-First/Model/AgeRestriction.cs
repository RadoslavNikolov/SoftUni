﻿namespace Code_First.Model
{
    public enum AgeRestriction
    {
        Child,
        Teen,
        Adult
    }
}