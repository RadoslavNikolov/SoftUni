﻿namespace Code_First.DTO
{
    public class MovieDTO
    {
        public string Isbn { get; set; }

        public string Title { get; set; }

        public int AgeRestriction { get; set; } 

    }
}