﻿namespace Code_First.DTO
{
    public class RatingDTO
    {
        public string user { get; set; }

        public string movie { get; set; }

        public int rating { get; set; } 
    }
}