﻿namespace Code_First.DTO
{
    public class CountryDTO
    {
        public string Name { get; set; } 
    }
}