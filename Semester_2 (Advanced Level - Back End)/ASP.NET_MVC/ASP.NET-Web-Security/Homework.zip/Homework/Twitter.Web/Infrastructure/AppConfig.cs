﻿namespace Twitter.Web.Infrastructure
{
    public static class AppConfig
    {
        public const int TweetsPerPage = 10;
    }
}