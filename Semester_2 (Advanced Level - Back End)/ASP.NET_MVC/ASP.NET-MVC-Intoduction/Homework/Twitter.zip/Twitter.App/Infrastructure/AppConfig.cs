﻿namespace Twitter.App.Infrastructure
{
    public static class AppConfig
    {
        public const int TweetsPerPage = 10;
    }
}