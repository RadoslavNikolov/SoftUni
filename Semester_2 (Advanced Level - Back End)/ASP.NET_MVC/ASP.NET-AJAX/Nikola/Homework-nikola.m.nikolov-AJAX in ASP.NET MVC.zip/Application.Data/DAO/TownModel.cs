﻿namespace SoftUni.Blog.Data.DAO
{
    public class TownModel
    {
        public string Name { get; set; }
    }
}
