﻿namespace SoftUni.Blog.Models
{
    public enum Status
    {
        Married,
        Single
    }
}