﻿namespace Twitter.App.Models.ViewModels
{
    public class UserPreviewViewModel
    {
        public string Username { get; set; }
    }
}