﻿namespace Twitter.Models
{
    public enum FileType
    {
         Photo = 1
    }
}