﻿namespace Template.App.Infrastructure.Mapping
{
    public interface IMapFrom<T>
    {
         
    }
}