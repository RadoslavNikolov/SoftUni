﻿namespace Template.App.Infrastructure
{
    public class AppConfig
    {
        public const int PageSize = 5;
    }
}